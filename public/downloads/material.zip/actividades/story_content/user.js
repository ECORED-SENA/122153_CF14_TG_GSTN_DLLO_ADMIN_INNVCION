function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6m5lVfaKptI":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

